const routes = {
    
    "/goods/list": "/goodsList"
}

module.exports = routes;